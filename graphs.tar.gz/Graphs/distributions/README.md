Parameters
---------------------
*These histograms were created by running the markov chain for x amounts of steps, then drawing 500 consecutive samples from 64 machines
*The values of the observables by treating each set of 64 measurements seperately and calculating the heat capacity and suceptibility from that